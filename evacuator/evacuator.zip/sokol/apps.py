from django.apps import AppConfig


class SokolConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sokol'
